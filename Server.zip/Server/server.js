const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const mongoose = require('mongoose');
const app = express();
const port = 1999;
const usersRouter = require('./routes/users');

app.use(cors());
app.use(bodyParser.json());


app.get('/', (req, res) => {
    res.send('Hello World our server ins running and it is time to GARDEN!');
});


mongoose.connect('mongodb+srv://YWilliams:RunForTheLight8$@cluster0.7gc6a.mongodb.net/MYGARDEINGAPP?retryWrites=true&w=majority', {
    useNewUrlParser: true,
    useUnifiedTopology: true
});

const db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function() {
    console.log("That's what's up we're connected!");
});
app.use('/users', usersRouter);


app.listen(port, () => {
    console.log(`Example app listening at http://localhost:${port}`);
});