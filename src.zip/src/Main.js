import React, { Component } from "react";
import {
    Route,
    NavLink,
    HashRouter
} from "react-router-dom";
import Home from "./Home";
import Stuff from "./Stuff";
import Login from "./Login";
import Register from "./Register";
import Contact from "./Contact";
class Main extends Component {
    render() {
        return ( <
            HashRouter >
            <
            div >
            <
            h1 > Ancient Manna Gardening < /h1> <
            ul className = "header" >
            <
            li > < NavLink to = "/" > Home < /NavLink></li >
            <
            li > < NavLink to = "/stuff" > Stuff < /NavLink></li >
            <
            li > < NavLink to = "/login" > Login < /NavLink></li >
            <
            li > < NavLink to = "/register" > Register < /NavLink></li >



            <
            li > < NavLink to = "/contact" > Contact < /NavLink></li >
            <
            /ul> <div className="content"> <
            Route exact path = "/"
            component = { Home }
            /> <
            Route path = "/stuff"
            component = { Stuff }
            /> <
            Route path = "/login"
            component = { Login }
            /> <
            Route path = "/register"
            component = { Register }
            /> <
            Route path = "/contact"
            component = { Contact }
            /> < /
            div > <
            /div> < /
            HashRouter >
        );
    }
}
export default Main;