import React, { Component } from "react";

class Contact extends Component {
    render() {
        return ( <
            div >
            <
            p > Cras facilisis urna ornare ex volutpat, et convallis erat elementum.Ut aliquam, ipsum vitae gravida suscipit, metus dui bibendum est, eget rhoncus nibh metus nec massa.Maecenas hendrerit laoreet augue nec molestie.Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. < /p>

            <
            p > Duis a turpis sed lacus dapibus elementum sed eu lectus. < /p>  <
            h2 > GOT QUESTIONS ? < /h2> <
            p > If you don 't know where to start please contact our allfilliate  <
            a href = "http://www.hebrewmountainmanna.biz/" > Our Partners < /a>. < /
            p > <
            /div>
        );
    }
}
export default Contact;